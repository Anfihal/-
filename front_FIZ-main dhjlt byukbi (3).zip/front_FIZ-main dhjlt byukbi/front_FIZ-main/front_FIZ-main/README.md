npm install framer-motion
npm install react-router-dom
npm install react-scripts
npm install react-icons
npm install axios
npm start# zavodhak

# zavodhak
# zavodhak3

import React from "react";

function PasswordResetForm() {
    return (
        <h2>In development</h2>
    );
}

export default PasswordResetForm;